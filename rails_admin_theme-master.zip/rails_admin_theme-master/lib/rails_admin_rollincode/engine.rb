module RailsAdminRollincode
  class Engine < ::Rails::Engine
  end
end
