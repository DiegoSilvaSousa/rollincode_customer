require 'rails_admin_rollincode/engine'

module RailsAdminRollincode
end
